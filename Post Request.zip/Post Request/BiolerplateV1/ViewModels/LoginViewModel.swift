//
//  PostViewModel.swift
//  BiolerplateV1
//
//  Created by Shourob Datta on 3/8/23.
//

import Foundation

class LoginViewModel: ObservableObject {
    
    @Published var fullName: String = ""
    @Published var email: String = ""
    @Published var showAlert = false
    @Published var alertMessage = ""
    @Published var isLoading: Bool = false

    private let service: ServiceProtocol

    init(service: ServiceProtocol) {
        self.service = service
    }
    
    func validateAndLogin() async {
        // Perform validation on the full name and email here
        if isValidFullName(fullName) && isValidEmail(email) {
            // Call the service class with the validated parameters
            await service.loginUser(fullName: fullName, email: email) { [weak self] result in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let isLoggedIn):
                        // Handle the result of the API request here
                       // self?.handleLoginResult(isLoggedIn: true)
                        print("")
                    case .failure(let error):
                        // Handle API or validation error
                     //   self?.showAlert = true
                    // self?.alertMessage = error.localizedDescription
                        print("")

                    }
                }
            }
        } else {
            // If validation fails, handle the error appropriately
            showAlert = true
            alertMessage = "Invalid full name or email"
        }
    }
    
     func handleLoginResult(isLoggedIn: Bool) {
        if isLoggedIn {
            // Handle successful login
            showAlert = true
            alertMessage = "Login successful!"
        } else {
            // Handle login failure
            showAlert = true
            alertMessage = "Login failed!"
        }
    }
    
     func isValidFullName(_ fullName: String) -> Bool {
        // Implement full name validation logic here
        // For example, you can check if it's not empty and contains only valid characters
        return !fullName.isEmpty
    }
    
     func isValidEmail(_ email: String) -> Bool {
        // Implement email validation logic here
        // For example, you can use a regular expression to validate the email format
        return email.contains("@") && email.contains(".")
    }
}

     
