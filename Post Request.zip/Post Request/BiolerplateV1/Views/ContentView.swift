//
//  ContentView.swift
//  BiolerplateV1
//
//  Created by Shourob Datta on 3/8/23.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = LoginViewModel(service: LoginService())
    
    var body: some View {
        VStack {
            TextField("Full Name", text: $viewModel.fullName)
                .padding()
            TextField("Email", text: $viewModel.email)
                .padding()
            Button("Login") {
                // Call the ViewModel's validation method
                Task {
                    await viewModel.validateAndLogin()
                }
            }
        }
        .padding()
        .alert(isPresented: $viewModel.showAlert) {
            Alert(title: Text("Login Result"), message: Text(viewModel.alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
