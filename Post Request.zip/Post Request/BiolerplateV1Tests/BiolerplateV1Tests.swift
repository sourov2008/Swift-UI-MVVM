////
////  BiolerplateV1Tests.swift
////  BiolerplateV1Tests
////
////  Created by Shourob Datta on 3/8/23.
////
//
import XCTest
@testable import BiolerplateV1 // Replace with your app name

final class LoginViewModelTests: XCTestCase {
    
    var viewModel: LoginViewModel!

    override func setUpWithError() throws {
        viewModel = LoginViewModel(service: LoginService())
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }

    func testValidFullName() {
        // Test with valid full name
        viewModel.fullName = "John Doe"
        XCTAssertTrue(viewModel.isValidFullName(viewModel.fullName))
    }

    func testInvalidFullName() {
        // Test with empty full name
        viewModel.fullName = ""
        XCTAssertFalse(viewModel.isValidFullName(viewModel.fullName))
    }

    func testValidEmail() {
        // Test with valid email
        viewModel.email = "john.doe@example.com"
        XCTAssertTrue(viewModel.isValidEmail(viewModel.email))
    }

    func testInvalidEmail() {
        // Test with invalid email format
        viewModel.email = "john.doe"
        XCTAssertFalse(viewModel.isValidEmail(viewModel.email))
    }

    // Add more test cases as needed for additional validation logic
}
