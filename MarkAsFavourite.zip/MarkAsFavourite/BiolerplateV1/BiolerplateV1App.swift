//
//  BiolerplateV1App.swift
//  BiolerplateV1
//
//  Created by Shourob Datta on 3/8/23.
//

/*
 */

import SwiftUI

@main
struct BiolerplateV1App: App {
    var body: some Scene {
        WindowGroup {
            PostListView()
        }
    }
}
